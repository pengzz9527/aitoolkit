---
title: "文本计数器"
description: "在线统计文字数量 — 中英文字数、字符数、行数、段落数实时统计，支持粘贴文本或直接输入"
keywords: ["文本计数器", "字数统计", "字符统计", "在线字数统计", "文字计数工具"]
icon: "📝"
type: "tools"
categories: ["文本处理"]
weight: 2
---
